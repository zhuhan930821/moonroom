# Moonroom visual reference asset pack

Source: user-provided concept image, 1536x864.

This pack contains individually cropped **reference images**, not transparent cutouts or 3D meshes. Crops deliberately overlap, and objects may be partially occluded. The concept image is a stylized illustration, so it cannot determine exact geometry or unseen backsides.

Use asset_inventory.csv as the task list. Model one asset at a time in Blender, with an editable .blend and exportable .glb, preview render, and Three.js screenshot. Do not model everything at once.

IMPORTANT: D01 drum kit is an existing approved asset; do not rebuild it. E01 is visually a large bed/daybed/lounging surface in the foreground; distinguish bed and sofa functions against actual scene geometry before replacing either.

Do not split textile folds into individual GLBs. Use sculpting or cloth simulation for duvet and blankets; use shared mesh/material components for hard-surface and repeated props.

## Codex single-asset template

Read asset_inventory.csv and inspect the reference crop for {ASSET_ID}. Inspect its position and neighboring objects in Moonroom_Annotated_Overview.png. Identify if the current project has a placeholder for this asset. Only create or replace {ASSET_ID}. Prefer a high-quality licensed base mesh for difficult organic objects. Use Blender for all visible geometry and material authoring; Three.js only for runtime composition and interaction. Produce source.blend, optimized.glb, PBR texture maps, and 3 preview renders. Verify GLB appearance in Three.js. Do not modify other assets or existing interactions. Stop for visual approval.
